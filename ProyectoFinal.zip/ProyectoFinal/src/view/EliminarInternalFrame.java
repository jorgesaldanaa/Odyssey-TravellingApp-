package view;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import com.toedter.calendar.JCalendar;

import control.ControladorEliminar;
import control.SistemaReservas;
import model.Actividad;
import model.Reserva;
import model.Usuario;

public class EliminarInternalFrame extends JInternalFrame {
    public SistemaReservas sistema;
    public JComboBox comboBox;
    public JComboBox alternateComboBox;
    public JSpinner horaSpinner;
    public JButton eliminarReservaButton;
    public JButton eliminarActividadButton;
    public JButton eliminarUsuarioButton;
    public JButton exitButton;
    public JLabel label1;
    public JLabel label2;
    public JLabel label3;
    public JLabel label4;
    public JCalendar fechaCalendar;
    public JTextField textField1;
    public JTextField textField2;
    public JTextField textField3;
    public ControladorEliminar controlador;

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public EliminarInternalFrame(Usuario[] usuarioArray, SistemaReservas sistema) {
        controlador = new ControladorEliminar(this, sistema);

        this.sistema = sistema;

        label1 = new JLabel("Usuario:");

        comboBox = new JComboBox(usuarioArray);
        comboBox.addActionListener(controlador);

        eliminarUsuarioButton = new JButton("Eliminar");
        eliminarUsuarioButton.addActionListener(controlador);

        this.add(label1);
        this.add(comboBox);
        this.add(eliminarUsuarioButton);

        this.setPresets();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public EliminarInternalFrame(Actividad[] actividadArray, SistemaReservas sistema) {
        controlador = new ControladorEliminar(this, sistema);

        this.sistema = sistema;

        label1 = new JLabel("Actividad:");

        comboBox = new JComboBox(actividadArray);
        comboBox.addActionListener(controlador);

        eliminarActividadButton = new JButton("Eliminar");
        eliminarActividadButton.addActionListener(controlador);

        this.add(label1);
        this.add(comboBox);
        this.add(eliminarActividadButton);

        this.setPresets();
    }

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public EliminarInternalFrame(Reserva[] reservaArray, SistemaReservas sistema) {
        controlador = new ControladorEliminar(this, sistema);

        this.sistema = sistema;

        label1 = new JLabel("Actividad:");

        comboBox = new JComboBox(reservaArray);
        comboBox.addActionListener(controlador);

        eliminarReservaButton = new JButton("Eliminar");
        eliminarReservaButton.addActionListener(controlador);

        this.add(label1);
        this.add(comboBox);

        label2 = new JLabel();
        this.reloadLabelInfo(label2, comboBox.getSelectedItem().toString());
        this.add(label2);

        this.add(eliminarReservaButton);

        this.setPresets();
    }

    public void reloadLabelInfo(JLabel label, String string) {

        label.setText(string);

        label.setVisible(false);
        label.setVisible(true);
    }

    public void setPresets() {
        controlador = new ControladorEliminar(this, sistema);

        exitButton = new JButton("Salir");
        exitButton.addActionListener(controlador);

        this.setLayout(new FlowLayout(ERROR, 10, 10));
        this.add(exitButton);
        this.setSize(400, 300);
        this.setVisible(true);
    }
}
