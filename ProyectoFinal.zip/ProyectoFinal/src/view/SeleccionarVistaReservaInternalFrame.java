package view;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;

import control.ControladorVistaReserva;
import control.SistemaReservas;
import model.Actividad;
import model.Usuario;

public class SeleccionarVistaReservaInternalFrame extends JInternalFrame {
    private SistemaReservas sistema;
    public JComboBox generalComboBox;
    public JComboBox secondaryComboBox;
    public JButton verButton;
    public JButton exitButton;

    public ControladorVistaReserva controlador;

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public SeleccionarVistaReservaInternalFrame(Actividad[] arrayActividades, SistemaReservas sistema) {
        controlador = new ControladorVistaReserva(sistema, this);

        this.sistema = sistema;

        generalComboBox = new JComboBox(arrayActividades);

        this.setPresets();
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public SeleccionarVistaReservaInternalFrame(Usuario[] arrayUsuarios, SistemaReservas sistema) {
        controlador = new ControladorVistaReserva(sistema, this);
        this.sistema = sistema;

        generalComboBox = new JComboBox(arrayUsuarios);

        this.setPresets();
    }

    public void setPresets() {
        controlador = new ControladorVistaReserva(sistema, this);

        verButton = new JButton("Ver");
        verButton.addActionListener(controlador);
        exitButton = new JButton("Salir");
        exitButton.addActionListener(controlador);

        this.setLayout(new FlowLayout(ERROR, 10, 10));
        this.add(generalComboBox);
        this.add(verButton);
        this.add(exitButton);
        this.setSize(400, 300);
        this.setVisible(true);
    }

}
