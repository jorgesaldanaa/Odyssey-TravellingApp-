package view;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import control.*;
import model.*;

public class VentanaEstadisticaActividad extends JInternalFrame {
    SistemaReservas miSistema;
    ControladorEstadistica ControladorEstadistica = new ControladorEstadistica(miSistema, this);
    public JTextArea info;
    public JButton exitButton;

    public VentanaEstadisticaActividad(Actividad[] listActividades, SistemaReservas sistema) {
        miSistema = sistema;
        this.setTitle("Estadísticas por Actividad");
        info = new JTextArea(ControladorFichero.estadisticasDeActividades(sistema.listaUsuarios, sistema.listaActividades, sistema.listaReservas));
        info.setEditable(false);
        info.setLineWrap(true); // Habilitar ajuste de línea
        info.setWrapStyleWord(true); // Ajuste de palabras
        exitButton = new JButton("Salir");
        exitButton.addActionListener(ControladorEstadistica);
        this.setLayout(new BorderLayout());
        this.add(new JScrollPane(info), BorderLayout.CENTER);// Añadir el JTextArea dentro de un JScrollPane al centro del frame
        JPanel buttonPanel = new JPanel();// Crear un panel para el botón y añadirlo al sur del frame
        buttonPanel.add(exitButton);
        this.add(buttonPanel, BorderLayout.SOUTH);
        this.setSize(400, 300);
        this.setDefaultCloseOperation(JInternalFrame.DISPOSE_ON_CLOSE);
        this.setVisible(true);
    }
}
