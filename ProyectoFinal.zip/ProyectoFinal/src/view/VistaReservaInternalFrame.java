package view;

import javax.swing.JInternalFrame;
import javax.swing.JTextArea;

import model.Actividad;
import model.Usuario;

public class VistaReservaInternalFrame extends JInternalFrame {
    public JTextArea textArea;

    public VistaReservaInternalFrame(Usuario usuario) {
        textArea = new JTextArea(usuario.imprimirReservas());
        this.setup();
    }

    public VistaReservaInternalFrame(Actividad actividad) {
        textArea = new JTextArea(actividad.imprimirReservas());
        this.setup();
    }

    public void setup() {
        this.setSize(600, 400);
        this.add(textArea);
        this.setVisible(true);
    }
}
