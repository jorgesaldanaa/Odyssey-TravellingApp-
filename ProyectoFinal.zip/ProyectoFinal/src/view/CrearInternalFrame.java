package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import com.toedter.calendar.JCalendar;

import control.ControladorCrear;
import control.SistemaReservas;
import model.Actividad;
import model.Usuario;

public class CrearInternalFrame extends JInternalFrame {
    public SistemaReservas sistema;
    public JComboBox userComboBox;
    public JComboBox alternateComboBox;
    public JSpinner horaSpinner;
    public JButton crearReservaButton;
    public JButton crearActividadButton;
    public JButton crearUsuarioButton;
    public JButton exitButton;
    public JLabel label1;
    public JLabel label2;
    public JLabel label3;
    public JLabel label4;
    public JCalendar fechaCalendar;
    public JTextField textField1;
    public JTextField textField2;
    public JTextField textField3;
    public ControladorCrear controlador;

    @SuppressWarnings({ "rawtypes", "unchecked" })
    public CrearInternalFrame(Usuario[] arrayUsuarios, Actividad[] arrayActividades,
            SistemaReservas sistema) {
        this.sistema = sistema;

        controlador = new ControladorCrear(this, sistema);

        userComboBox = new JComboBox(arrayUsuarios);
        userComboBox.addActionListener(controlador);

        alternateComboBox = new JComboBox(arrayActividades);
        userComboBox.addActionListener(controlador);

        label1 = new JLabel("Usuario:");
        label2 = new JLabel("Actividad");
        label3 = new JLabel("Fecha");
        label4 = new JLabel("Hora");

        crearReservaButton = new JButton("Nueva Reserva");
        crearReservaButton.addActionListener(controlador);

        fechaCalendar = new JCalendar();

        SpinnerNumberModel modeloHora = new SpinnerNumberModel(0, 0, 23, 1);
        horaSpinner = new JSpinner(modeloHora);

        this.add(label1);
        this.add(userComboBox);
        this.add(label2);
        this.add(alternateComboBox);
        this.add(label3);
        this.add(fechaCalendar);
        this.add(label4);
        this.add(horaSpinner);
        this.add(crearReservaButton);

        this.setPresets();

    }

    public CrearInternalFrame(Usuario[] arrayUsuarios, SistemaReservas sistema) {

        controlador = new ControladorCrear(this, sistema);

        label1 = new JLabel("DNI:");
        textField1 = new JTextField() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 20);
            }
        };

        label2 = new JLabel("Nombre:");
        textField2 = new JTextField() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 20);
            }
        };

        label3 = new JLabel("Fecha de nacimiento:");
        fechaCalendar = new JCalendar();

        crearUsuarioButton = new JButton("Crear");
        crearUsuarioButton.addActionListener(controlador);

        this.add(label1);
        this.add(textField1);
        this.add(label2);
        this.add(textField2);
        this.add(label3);
        this.add(fechaCalendar);
        this.add(crearUsuarioButton);

        this.setPresets();
    }

    public CrearInternalFrame(Actividad[] actividadArray, SistemaReservas sistema) {
        controlador = new ControladorCrear(this, sistema);

        label1 = new JLabel("Nuevo ID:");
        textField1 = new JTextField() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 20);
            }
        };

        label2 = new JLabel("Nuevo Nombre:");
        textField2 = new JTextField() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 20);
            }
        };

        label3 = new JLabel("Aforo:");
        textField3 = new JTextField() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(100, 20);
            }
        };

        crearActividadButton = new JButton("Crear");
        crearActividadButton.addActionListener(controlador);

        this.add(label1);
        this.add(textField1);
        this.add(label2);
        this.add(textField2);
        this.add(label3);
        this.add(textField3);
        this.add(crearActividadButton);

        this.setPresets();
    }

    public void setPresets() {
        exitButton = new JButton("Salir");
        exitButton.addActionListener(controlador);

        this.setLayout(new FlowLayout(ERROR, 10, 10));
        this.add(exitButton);
        this.setSize(400, 300);
        this.setVisible(true);
    }

}
