package control;

import java.util.ArrayList;

import model.Actividad;
import model.Reserva;
import model.Usuario;
import view.VentanaPrincipal;

public class SistemaReservas {
    public ArrayList<Actividad> listaActividades;
    public ArrayList<Usuario> listaUsuarios;
    public ArrayList<Reserva> listaReservas;
    public VentanaPrincipal ventanaPrincipal;
    public ControladorFichero controladorFichero;
    public final String URL_USUARIOS = "OOP\\ProyectoFinal\\data\\FicheroUsuarios.txt";
    public final String URL_ACTIVIDADES = "OOP\\ProyectoFinal\\data\\FicheroActividades.txt";
    public final String URL_RESERVAS = "OOP\\ProyectoFinal\\data\\FicheroReservas.txt";

    public static void main(String[] args) {
        SistemaReservas sistema = new SistemaReservas();

    }

    public SistemaReservas() {
        ControladorMenu controladorMenu = new ControladorMenu(this);
        this.ventanaPrincipal = new VentanaPrincipal(controladorMenu);
        controladorMenu.setVentanaPrincipal(ventanaPrincipal);
    }

    public ArrayList<Actividad> getListaActividades() {
        return listaActividades;
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

}