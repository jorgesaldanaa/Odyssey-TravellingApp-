package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.*;
import view.VentanaEstadisticaActividad;
import view.VentanaEstadisticaUsuario;
import view.VentanaEstadisticaTop3Usuario;

public class ControladorEstadistica implements ActionListener {

	SistemaReservas sistema;
	VentanaEstadisticaUsuario ventanaUsuario;
	VentanaEstadisticaActividad ventanaActividad;
	VentanaEstadisticaTop3Usuario ventanaTop3U;
	VentanaEstadisticaTop3Actividad ventanaTop3A;
	ControladorFichero controladorFichero;

	public ControladorEstadistica(SistemaReservas sistema, VentanaEstadisticaUsuario ventana) {
		this.sistema = sistema;
		this.ventanaUsuario = ventana;
	}

	public ControladorEstadistica(SistemaReservas sistema, VentanaEstadisticaActividad ventana) {
		this.sistema = sistema;
		this.ventanaActividad = ventana;
	}

	public ControladorEstadistica(SistemaReservas sistema, VentanaEstadisticaTop3Usuario ventana) {
		this.sistema = sistema;
		this.ventanaTop3U = ventana;
	}

	public ControladorEstadistica(SistemaReservas sistema, VentanaEstadisticaTop3Actividad ventana) {
		this.sistema = sistema;
		this.ventanaTop3A = ventana;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (ventanaUsuario != null && e.getSource() == ventanaUsuario.exitButton) {
			ventanaUsuario.dispose();
		} else if (ventanaActividad != null && e.getSource() == ventanaActividad.exitButton) {
			ventanaActividad.dispose();
		}
		if (ventanaTop3U != null && e.getSource() == ventanaTop3U.exitButton) {
			ventanaTop3U.dispose();
		} else if (ventanaTop3A != null && e.getSource() == ventanaTop3A.exitButton) {
			ventanaTop3A.dispose();
		} else {
			System.out.println("Error");
		}
	}
}
