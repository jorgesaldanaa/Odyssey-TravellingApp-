package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.Actividad;
import model.Reserva;
import model.Usuario;
import view.EliminarInternalFrame;

public class ControladorEliminar implements ActionListener {

    public SistemaReservas sistema;
    public EliminarInternalFrame ventana;

    public ControladorEliminar(EliminarInternalFrame ventana, SistemaReservas sistema) {
        this.sistema = sistema;
        this.ventana = ventana;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ventana.eliminarUsuarioButton) {
            try {
                Usuario selectedUsuario = (Usuario) ventana.comboBox.getSelectedItem();

                String DNI = selectedUsuario.getDni();

                sistema.getListaUsuarios().remove(selectedUsuario);
                ControladorFichero.bajaUsuario(sistema.listaUsuarios, sistema.URL_USUARIOS, DNI);
                System.out.println(sistema.getListaUsuarios());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }
        } else if (e.getSource() == ventana.eliminarActividadButton) {
            try {
                Actividad selectedActividad = (Actividad) ventana.comboBox.getSelectedItem();

                int id = selectedActividad.getId();

                sistema.getListaActividades().remove(selectedActividad);
                ControladorFichero.bajaActividad(sistema.listaActividades, id, sistema.URL_ACTIVIDADES);
                System.out.println(sistema.getListaActividades());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }

        } else if (e.getSource() == ventana.eliminarReservaButton) {
            try {
                Reserva selectedReserva = (Reserva) ventana.comboBox.getSelectedItem();

                sistema.getListaReservas().remove(selectedReserva);

                ControladorFichero.cancelarReserva(sistema.listaUsuarios, sistema.listaActividades,
                        sistema.listaReservas, sistema.URL_RESERVAS, selectedReserva);

                System.out.println(sistema.getListaReservas());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }

        } else if (e.getSource() == ventana.comboBox) {
            try {
                if (ventana.comboBox.getSelectedItem() instanceof Reserva) {
                    Reserva reserva = (Reserva) ventana.comboBox.getSelectedItem();

                    for (Usuario u : sistema.listaUsuarios) {
                        if (u.getDni().equals(reserva.getDni())) {
                            ventana.reloadLabelInfo(ventana.label2, u.getNombre());
                        }
                    }
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }

        } else if (e.getSource() == ventana.exitButton) {
            ventana.dispose();
        } else {
            System.out.println("Unknown Crear Action" + e);
        }
    }

}
