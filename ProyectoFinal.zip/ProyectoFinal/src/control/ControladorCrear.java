package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JOptionPane;

import model.Actividad;
import model.Reserva;
import model.Usuario;
import view.CrearInternalFrame;

public class ControladorCrear implements ActionListener {
    public SistemaReservas sistema;
    public CrearInternalFrame ventana;

    public ControladorCrear(CrearInternalFrame ventana, SistemaReservas sistema) {
        this.sistema = sistema;
        this.ventana = ventana;
    }

    // organize user-->actividad-->reserva
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ventana.crearReservaButton) {
            try {
                Date fecha = ventana.fechaCalendar.getDate();
                Calendar calendarObject = Calendar.getInstance();
                calendarObject.setTime(fecha);

                String dia = "" + revisarFormatoFecha(calendarObject.get(Calendar.DAY_OF_MONTH));
                String mes = "" + revisarFormatoFecha(calendarObject.get(Calendar.MONTH));
                String año = "" + calendarObject.get(Calendar.YEAR);

                String fechaString = dia + mes + año;

                Usuario usuarioSeleccionado = (Usuario) ventana.userComboBox.getSelectedItem();
                Actividad actividadSeleccionada = (Actividad) ventana.alternateComboBox.getSelectedItem();
                int horaSeleccionada = (Integer) ventana.horaSpinner.getValue();

                ControladorFichero.crearReserva(sistema.listaUsuarios, sistema.listaActividades, sistema.listaReservas,
                        usuarioSeleccionado, actividadSeleccionada, sistema.URL_RESERVAS, fechaString,
                        horaSeleccionada);

                Reserva nuevaReserva = new Reserva(usuarioSeleccionado.getDni(), actividadSeleccionada.getId(),
                        fechaString, horaSeleccionada);

                sistema.getListaReservas().add(nuevaReserva);

                System.out.println(sistema.getListaReservas());

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(ex);
            }

        } else if (e.getSource() == ventana.crearActividadButton) {

            try {
                int id = Integer.parseInt(ventana.textField1.getText());
                String nombre = (String) ventana.textField2.getText();
                int aforo = Integer.parseInt(ventana.textField3.getText());

                System.out.println(id + nombre + aforo);

                ControladorFichero.altaActividad(sistema.listaActividades, sistema.URL_ACTIVIDADES, id, nombre, aforo);
                Actividad actividadNueva = new Actividad(id, nombre, aforo);
                sistema.listaActividades.add(actividadNueva);
            } catch (Exception e1) {
                JOptionPane.showMessageDialog(ventana, e1, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(e1);

            }

        } else if (e.getSource() == ventana.crearUsuarioButton) {

            try {
                Date fecha = ventana.fechaCalendar.getDate();
                Calendar calendarObject = Calendar.getInstance();
                calendarObject.setTime(fecha);

                String fechaString = "" + calendarObject.get(Calendar.YEAR);

                String DNI = (String) ventana.textField1.getText();
                String nombre = (String) ventana.textField2.getText();

                ControladorFichero.altaUsuario(sistema.listaUsuarios, sistema.URL_USUARIOS, DNI, nombre, fechaString);
                Usuario usuarioNuevo = new Usuario(DNI, nombre, fechaString);
                sistema.listaUsuarios.add(usuarioNuevo);
                System.out.println(usuarioNuevo.toString());

            } catch (Exception e1) {
                JOptionPane.showMessageDialog(ventana, e1, "Error de input", JOptionPane.ERROR_MESSAGE);
                System.out.println(e1);

            }
        } else if (e.getSource() == ventana.exitButton) {
            ventana.dispose();
        } else {
            System.out.println("Unknown Crear Action" + e);
        }

    }

    public String revisarFormatoFecha(int fecha) {
        String fechaString = "" + fecha;

        if (fechaString.length() == 1) {
            fechaString = "0" + fecha;
            return fechaString;

        } else {
            return fechaString;

        }
    }
}
