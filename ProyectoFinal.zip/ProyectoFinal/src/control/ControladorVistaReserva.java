package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import model.Actividad;
import model.Reserva;
import model.Usuario;
import view.InformacionDialog;
import view.SeleccionarVistaReservaInternalFrame;

public class ControladorVistaReserva implements ActionListener {
    public SistemaReservas sistema;
    public SeleccionarVistaReservaInternalFrame ventana;

    public ControladorVistaReserva(SistemaReservas sistema, SeleccionarVistaReservaInternalFrame ventana) {
        this.sistema = sistema;
        this.ventana = ventana;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ventana.verButton) {
            if (ventana.generalComboBox.getSelectedItem() instanceof Usuario) {
                try {
                    Usuario usuario = (Usuario) ventana.generalComboBox.getSelectedItem();

                    String listaReservaString = "";
                    for (Reserva reserva : usuario.getListaReservas()) {
                        listaReservaString = listaReservaString + reserva.toString() + "\n";
                    }

                    new InformacionDialog(listaReservaString, sistema.ventanaPrincipal);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                    System.out.println(ex);
                }

            } else if (ventana.generalComboBox.getSelectedItem() instanceof Actividad) {
                try {
                    Actividad actividad = (Actividad) ventana.generalComboBox.getSelectedItem();

                    String listaReservaString = "";
                    for (Reserva reserva : actividad.getListaReservas()) {
                        listaReservaString = listaReservaString + reserva.toString() + "\n";
                    }

                    new InformacionDialog(listaReservaString, sistema.ventanaPrincipal);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(ventana, ex, "Error de input", JOptionPane.ERROR_MESSAGE);
                    System.out.println(ex);
                }
            } else {
                System.out.println(
                        "Seleccion fuera de clases aceptadas" + ventana.generalComboBox.getSelectedItem().getClass());
            }

        } else if (e.getSource() == ventana.exitButton) {
            ventana.dispose();

        } else {
            System.out.println("Unknown source" + e);
        }
    }

}
